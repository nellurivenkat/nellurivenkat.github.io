package com.app.venkatmoviesystem;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatImageView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.material.textview.MaterialTextView;

import java.util.List;

public class MAdapter extends RecyclerView.Adapter<MAdapter.ViewHolder> {

    private Context context;
    private List<Movie> list;
    private OnItemClickListener listener;

    public MAdapter(Context context, List<Movie> list) {
        this.context = context;
        this.list = list;
    }

    public void setOnItemClickListener(OnItemClickListener listener){
        this.listener = listener;
    }

    interface OnItemClickListener{
        void onClick(int position);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.movie_item_row, parent, false);

        return new ViewHolder(view, listener);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
         Movie item = list.get(position);
         holder.dataBinding(item,context);
    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder{
        MaterialTextView mname;
        AppCompatImageView mimage;
        MaterialTextView mstarring;
        MaterialTextView mcertification;
        MaterialTextView mrunningtime;
        AppCompatImageView simage;
        MaterialTextView stextview;
        AppCompatImageView ffast;

        OnItemClickListener mListener;
        public ViewHolder(@NonNull View itemView,OnItemClickListener listener) {
            super(itemView);
            mListener = listener;
            mname = itemView.findViewById(R.id.mname);
            mimage = itemView.findViewById(R.id.mimage);
            mstarring = itemView.findViewById(R.id.mstarring);
            mcertification = itemView.findViewById(R.id.mcertifications);
            mrunningtime = itemView.findViewById(R.id.mrunningtime);
            simage = itemView.findViewById(R.id.chair);
            stextview = itemView.findViewById(R.id.seatstextview);
            ffast = itemView.findViewById(R.id.fillingfast);
        }

        void dataBinding(Movie movie,Context context) {
            Glide
                    .with(context)
                    .load(movie.image)
                    .into(mimage);
            mname.setText(movie.name);
            mstarring.setText(movie.starring);
            mrunningtime.setText(movie.running_time_mins);
            mcertification.setText(movie.certification);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mListener.onClick(getLayoutPosition());
                }
            });


            if (movie.seats_selected == 0){
                stextview.setText(movie.seats_remaining+" seats remaining");
                simage.setColorFilter(Color.parseColor("#ffffff"), android.graphics.PorterDuff.Mode.MULTIPLY);
                stextview.setTextColor(Color.parseColor("#ffffff"));
            }
            else{
                stextview.setText(movie.seats_selected+" seats selected");
                simage.setColorFilter(Color.parseColor("#008000"), android.graphics.PorterDuff.Mode.MULTIPLY);
                stextview.setTextColor(Color.parseColor("#008000"));

            }

            if (movie.seats_remaining != 0 && movie.seats_remaining < 3){
                ffast.setVisibility(View.VISIBLE);
            }
            else{
                ffast.setVisibility(View.GONE);
            }
        }
    }

}
