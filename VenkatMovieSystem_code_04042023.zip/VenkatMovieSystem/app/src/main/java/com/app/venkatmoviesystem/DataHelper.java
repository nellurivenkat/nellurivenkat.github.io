package com.app.venkatmoviesystem;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class DataHelper {

    static List<Movie> getList() {
        List<Movie> list = new ArrayList<>();

        list.add(new Movie("MUMMIES", "'Mummies' follows the fun adventures of three Egyptian mummies who live in an underground secret city, hidden in ancient Egypt.", "PG", "https://i.ytimg.com/vi/tYn8NCOJ86w/maxresdefault.jpg", "Eleanor Tomlinson, Sean Bean, Joe Thomas, Hugh Bonneville, Celia Imrie", "1hr 28mins", getRandNumber(), 0));
        list.add(new Movie("DC LEAGUE OF SUPER-PETS | MINI MORNINGS", "When Superman and the Justice League are kidnapped, Krypto must convince a rag-tag shelter pack - Ace the hound, PB the potbellied pig, Merton the turtle and Chip the squirrel - to master their own newfound powers and help him rescue the superheroes.", "PG", "https://metadata-static.plex.tv/7/gracenote/7cf7ea1b54e9f5f035d27710e407d00e.jpg", "Dwayne Johnson,Kevin Hart,Kate McKinnon", "1hr 45mins", getRandNumber(), 0));
        list.add(new Movie("SCREAM VI", "Following the latest Ghostface killings, the four survivors leave Woodsboro behind and start a fresh chapter.", "16", "https://sportshub.cbsistatic.com/i/2023/01/19/eacfd10f-ff6f-4e60-9768-07f7f2804b89/scream-vi-6-official-poster-2023-header.jpg", "Melissa Barrera, Jenna Ortega, Courteney Cox", "2hrs 2mins", getRandNumber(), 0));
        list.add(new Movie("CREED III", "When a childhood friend and former boxing prodigy, Damian (Jonathan Majors), resurfaces after serving a long sentence in prison, he is eager to prove that he deserves his shot in the ring.", "TBC", "https://thathashtagshow.com/wp-content/uploads/2023/02/Creed3.jpg", "Michael B. Jordan, Tessa Thompson, Jonathan Majors, Wood Harris", "1hr 56mins", getRandNumber(), 0));

        return list;
    }

    private static int getRandNumber(){
        return new Random().nextInt(15);
    }
}
