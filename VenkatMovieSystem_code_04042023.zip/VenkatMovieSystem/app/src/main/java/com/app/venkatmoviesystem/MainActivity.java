package com.app.venkatmoviesystem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements MAdapter.OnItemClickListener {
    public static List<Movie> mLists;

    private MAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mLists = new ArrayList<>();
        mLists.addAll(DataHelper.getList());

        RecyclerView recyclerView = findViewById(R.id.moviesrecyclerview);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        adapter = new MAdapter(this,mLists);
        recyclerView.setAdapter(adapter);
        adapter.setOnItemClickListener(this);


    }

    @Override
    protected void onResume() {
        super.onResume();
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onClick(int position) {
        Movie item = mLists.get(position);
        Intent intent = new Intent(this,DetailActivity.class);
        intent.putExtra("ITEM",item);
        intent.putExtra("INDEX",position);
        startActivity(intent);
    }
}