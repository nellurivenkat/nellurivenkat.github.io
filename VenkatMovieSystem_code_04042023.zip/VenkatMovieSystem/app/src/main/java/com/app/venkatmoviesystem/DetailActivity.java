package com.app.venkatmoviesystem;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageView;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;

import com.bumptech.glide.Glide;
import com.google.android.material.textview.MaterialTextView;

public class DetailActivity extends AppCompatActivity {

    private Movie movie=null;
    private MaterialTextView stextview;
    private AppCompatImageView decimage;
    private AppCompatImageView incimage;
    private MaterialTextView scounter;
    private int counter = 0;
    private int index = 0;
    private int tempseats = 0;
    private int finalrseats = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        MaterialTextView movieName = findViewById(R.id.mname);
        MaterialTextView movieDescription = findViewById(R.id.mdescription);
        AppCompatImageView movieImage = findViewById(R.id.mimage);
        MaterialTextView movieStarring = findViewById(R.id.mstarring);
        MaterialTextView movieCertification = findViewById(R.id.mcertifications);
        MaterialTextView movieRunningTime = findViewById(R.id.mrunningtime);
        AppCompatImageView seatImage = findViewById(R.id.chair);
        stextview = findViewById(R.id.stextview);
        decimage = findViewById(R.id.sdecrementview);
        incimage = findViewById(R.id.sincrementview);
        scounter = findViewById(R.id.scounterview);

        if (getIntent() != null && getIntent().hasExtra("ITEM")){
            index = getIntent().getIntExtra("INDEX",0);
            movie = (Movie) getIntent().getSerializableExtra("ITEM");

            Glide
                    .with(this)
                    .load(movie.image)
                .into(movieImage);
            movieName.setText(movie.name);
            movieDescription.setText(movie.description);
            movieStarring.setText(movie.starring);
            movieRunningTime.setText(movie.running_time_mins);
            movieCertification.setText(movie.certification);
                    tempseats = movie.seats_remaining + movie.seats_selected;
            if (movie.seats_selected == 0){
                stextview.setText(movie.seats_remaining+" seats remaining");
            }
            else{
                stextview.setText(movie.seats_remaining+" seats remaining");
                scounter.setText(""+movie.seats_selected);
                counter = movie.seats_selected;

            }

            if (movie.seats_selected == 0){
                decimage.setEnabled(false);
                decimage.setColorFilter(Color.parseColor("#cccccc"), android.graphics.PorterDuff.Mode.MULTIPLY);
            }
            else{
                decimage.setEnabled(true);
                decimage.setColorFilter(Color.parseColor("#ffffff"), android.graphics.PorterDuff.Mode.MULTIPLY);
            }

            if (movie.seats_remaining == 0){
                incimage.setEnabled(false);
                incimage.setColorFilter(Color.parseColor("#cccccc"), android.graphics.PorterDuff.Mode.MULTIPLY);
            }
            else{
                incimage.setEnabled(true);
                incimage.setColorFilter(Color.parseColor("#ffffff"), android.graphics.PorterDuff.Mode.MULTIPLY);
            }
        }

        decimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                counter -=1;
                if (counter >=0) {
                    scounter.setText(""+counter);
                    if (counter == 0) {
                        decimage.setEnabled(false);
                        decimage.setColorFilter(
                                Color.parseColor("#cccccc"),
                                android.graphics.PorterDuff.Mode.MULTIPLY
                        );
                    } else {
                        decimage.setEnabled(true);
                        decimage.setColorFilter(
                                Color.parseColor("#ffffff"),
                                android.graphics.PorterDuff.Mode.MULTIPLY
                        );
                        incimage.setEnabled(true);
                        incimage.setColorFilter(
                                Color.parseColor("#ffffff"),
                                android.graphics.PorterDuff.Mode.MULTIPLY
                        );
                    }
                    int result = Math.abs(counter - tempseats);
                    finalrseats = result;
                    stextview.setText(result+" seats remaining");
                }
            }
        });

        incimage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                counter +=1;
                if (counter <= tempseats) {
                    scounter.setText(""+counter);

                    if (counter == tempseats) {
                        incimage.setEnabled(false);
                        incimage.setColorFilter(
                                Color.parseColor("#cccccc"),
                                android.graphics.PorterDuff.Mode.MULTIPLY
                        );
                    } else {
                        incimage.setEnabled(true);
                        incimage.setColorFilter(
                                Color.parseColor("#ffffff"),
                                android.graphics.PorterDuff.Mode.MULTIPLY
                        );
                        decimage.setEnabled(true);
                        decimage.setColorFilter(
                                Color.parseColor("#ffffff"),
                                android.graphics.PorterDuff.Mode.MULTIPLY
                        );
                    }
                    int result = tempseats - counter;
                    finalrseats = result;
                    stextview.setText(result+" seats remaining");
                }
            }
        });

    }


    @Override
    public void onBackPressed() {
        movie.seats_remaining = finalrseats;
        movie.seats_selected = Integer.parseInt(scounter.getText().toString());
        MainActivity.mLists.remove(index);
        MainActivity.mLists.add(index,movie);
        super.onBackPressed();
    }
}